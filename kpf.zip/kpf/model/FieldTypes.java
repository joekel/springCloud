package org.kp.model;

public enum FieldTypes {

}
