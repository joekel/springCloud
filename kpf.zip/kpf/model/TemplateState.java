package org.kp.model;

public enum TemplateState {
	
	new_s,
	draft,
	review,
	rejected,
	final_s,
	published,
	deavtivated,
	deleted	


}
