package org.kp.model;

public enum ResourceState {
	new_s,
	draft,
	final_s,
	published,
	deactiveted,
	deleted
}
