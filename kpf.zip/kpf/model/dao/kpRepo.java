package org.kp.model.dao;

public class kpRepo {

}
