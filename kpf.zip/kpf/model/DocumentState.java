package org.kp.model;

public enum DocumentState {
	new_s,
	sate,
	draft,
	submited,
	archived,
	deleted	

}
